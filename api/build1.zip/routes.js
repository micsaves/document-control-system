const AWS = require("aws-sdk");
const express = require("express");

const IS_OFFLINE = process.env.NODE_ENV !== "production"; //condition if local or AWS

const RULEBOOK_USERS_TBL =
  IS_OFFLINE === true ? "rulebook_users_tbl" : process.env.RULEBOOK_USERS_TBL;

const RULEBOOK_DOCUMENTS_TBL =
  IS_OFFLINE === true
    ? "rulebook_documents_tbl"
    : process.env.RULEBOOK_DOCUMENTS_TBL;

const dynamoDb =
  IS_OFFLINE === true
    ? new AWS.DynamoDB.DocumentClient({
        region: "eu-east-2",
        endpoint: "http://localhost:8000"
      })
    : new AWS.DynamoDB.DocumentClient();

const router = express.Router();

router.get("/test", (req, res) => {
  // res.send("ルールブック AWS 📑💡");
  res.send("ANNYEONG");
});

// //GET ALL DATA (list)
router.get("/getAllUsers", (req, res) => {
  const params = { TableName: RULEBOOK_USERS_TBL };
  dynamoDb.scan(params, (error, result) => {
    if (error) {
      res.status(400).json({ error: "Error fetching the employees" });
    }
    res.send(result.Items);
  });
});

//GET USER INFO
router.get("/getUser/:user_id", (req, res) => {
  const params = {
    TableName: RULEBOOK_USERS_TBL,
    Key: { UserId: req.params.user_id }
  };
  dynamoDb.get(params, (error, result) => {
    if (error) {
      res.send(error.message);
    }
    if (result) {
      res.send(result.Item);
    }
  });
});

//ADD NEW USER
router.get("/registerUser", (req, res) => {
  let toAdd = {
    UserId: "03328",
    Password: "03328",
    Name: "ESTEBAN, JOAN R.",
    MailAddress: "sd2@hrd-s.com",
    UpdatedDate: "2020-09-15",
    RegisteredDate: "2020-09-15",
    RegisteredBy: "36822"
  };
  let params = { TableName: RULEBOOK_USERS_TBL, Item: toAdd };
  dynamoDb.put(params, (err) => {
    if (err) {
      console.log(err.message);
      res.send(err.message);
    } else {
      res.send("User Successfully Registered");
    }
  });
});

//UPDATE USER INFO
router.put("/updateUserAccount", (req, res) => {
  const params = { TableName: RULEBOOK_USERS_TBL, Item: req.body };

  dynamoDb.put(params, (error) => {
    if (error) {
      res.send(error.message);
    } else {
      res.send("Record Saved");
    }
  });
});

//HARD DELETE USER ACCOUNT
router.delete("/deleteUserAccount/:user_id", (req, res) => {
  const params = {
    TableName: RULEBOOK_USERS_TBL,
    Key: { UserId: req.params.user_id }
  };
  dynamoDb.delete(params, (error) => {
    if (error) {
      res.send(error.message);
    } else {
      res.send("User Account Successfully Deleted");
    }
  });
});

//GET ALL DOCUMENTS JWW
router.get("/getAllFiles", (req, res) => {
  const params = {
    TableName: RULEBOOK_DOCUMENTS_TBL
  };
  dynamoDb.scan(params, (error, result) => {
    if (error) {
      res.status(400).json({ error: "Error fetching the files" });
    }
    res.send(result.Items);
  });
});

// // import data
// const myData = require("./JWW.json");

// router.get("/bulkInsert", (req, res) => {
//   let toInsert = myData.map((rec) => {
//     delete rec._rev;
//     return rec;
//   });
//   // .filter((rec) => {
//   //   return typeof rec._id == "string";
//   // });
//   // res.send(toInsert);
//   var batchRequest = {};
//   var myArr = [];
//   for (let i = 0; i < toInsert.length / 25; i++) {
//     batchRequest = {};
//     myArr = [];
//     for (var j = i * 25; j < i * 25 + 25; j++) {
//       if (j < toInsert.length) {
//         let newData = toInsert[j];
//         myArr.push({ PutRequest: { Item: newData } });
//       }
//     }

//     batchRequest = {
//       RequestItems: {
//         [RULEBOOK_DOCUMENTS_TBL]: myArr
//       },
//     };
//     dynamoDb.batchWrite(batchRequest, (err) => {
//       if (err) {
//         console.log(err);
//       }
//     });
//   }
//   setTimeout(() => {
//     res.send("OK");
//   }, 50000);
// });

module.exports = router;
